None offical release. 

This version will most likley not work you may not even be able to create a new project.
Just stick to the helloworld project patch to play with.

This release is meant for working out bugs/tinkering and would not recommend using the patch in
its current state for a final product. Do not rely on its stability!

Some libraries are required to run this patch. 

iem-lib
else
zexy
hcs
list-abs

and

Clear Essentials can only be found via GitHub:
https://github.com/RetroMaximus/ClearEssentials

This zip contains ce_guieditor patch and help file along with helloworld scene text files. 

Working gui items in this version:
Bang
Toggle
Hslider
Vslider
Canvas

Known bugs:
Scene changes might crash after "drawnnumber_motion: scalar" in console.
When new items are added the item name may stay blank.  Rename the item and re-build to fix this.
Only the Item Header label shows when a items is created. Adjust the item size and re-build to fix this.
Header label shows as "symbol". Assign the header text label to fix this.


This patch was Written by
Reginald "ScriptAl1as" Finley
RF Production Systems
https://rfprd.wordpress.com

